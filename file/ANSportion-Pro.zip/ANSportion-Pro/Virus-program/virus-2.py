import time
import os
while True:
    os.system("start cmd.exe")
    time.sleep(0.05)#停顿时间